Opening the project folder in a terminal allows you to just use the 'make' command.
Make will clean the project folder of executables and rebuild them.
The make will take input from a file named "data.txt" so it makes your life easier if your
input file is named as such.
