#include <iostream>
#include <fstream>
#include "converter.hpp"

using namespace std;

Converter::Converter(
  std::vector<State> _listOfStates,
  std::vector<char> _inputs,
  int _numFinalStates,
  std::vector<int> _finalStates,
  int _numTransitions,
  int _initialState,
  int _totalStates)
{
  //IMPLEMENT ME
  //implMe();
  listOfStates = _listOfStates;
  inputs = _inputs;
  numFinalStates = _numFinalStates;
  finalStates = _finalStates;
  numTransitions = _numTransitions;
  initialState = _initialState;
  totalStates = _totalStates;
}

Converter::~Converter() {

}

void Converter::convertNfaToDfa() {
  //std::vector<Dfa> DStates;
  return;
}

bool Converter::DStateHolds(std::vector<Dfa> dfa, std::vector<int> nfaStates) {
  return false;
}

bool Converter::unmarked(std::vector<Dfa> Dstates) {
  return false;
}

int Converter::getFirstUnmarked(std::vector<Dfa> DStates) {
  return -1;
}

bool Converter::isEmpty() {
  //IMPLEMENT ME
  //implMe();
  return false;
}
